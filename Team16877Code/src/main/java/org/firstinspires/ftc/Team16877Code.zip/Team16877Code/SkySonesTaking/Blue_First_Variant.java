package org.firstinspires.ftc.Team16877Code.SkySonesTaking;

//import

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;
import java.util.List;

import org.firstinspires.ftc.Team16877Code.AutonautsAPI;
import org.firstinspires.ftc.robotcore.external.ClassFactory;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer.CameraDirection;
import org.firstinspires.ftc.robotcore.external.tfod.TFObjectDetector;
import org.firstinspires.ftc.robotcore.external.tfod.Recognition;

import static java.lang.Math.abs;

@Autonomous(name="BYXX")
public class Blue_First_Variant extends AutonautsAPI {

    @Override
    public void runOpMode() {

        boolean i = true;
        INIT();
        telemetry.addData("Status", "Initialized");
        telemetry.update();

        while (opModeIsActive()) {
            if(i){
                gettingServo(false);
                runRight(0.40,0.85);
                runForward(0.9,0.85);
                gettingServo(true);
                sleep(200);
                runBack(0.8,0.85);
                runLeft(0.95,0.85);
                gettingServo(false);
                sleep(200);
                runBack(0.10,0.85);

                runRight(1.65,0.85);

                runForward(0.9, 0.85);
                gettingServo(true);
                sleep(200);
                runBack(0.8, 0.85);
                runLeft(1.85, 0.85);
                gettingServo(false);
                sleep(200);
                runBack(0.10, 0.85);
                runRight(0.35, 0.85);

                i = !i;
            }
        }
    }
}
