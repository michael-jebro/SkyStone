package org.firstinspires.ftc.Team16877Code.PalletTake;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;

import org.firstinspires.ftc.Team16877Code.AutonautsAPI;

@Autonomous(name = "Red pallet take")

public class Red_Pallet_Take extends AutonautsAPI {

    @Override
    public void runOpMode()
    {
        INIT();

        int i =0;

        while (opModeIsActive())
        {
            turnTo(90,0.5);
            //runRight(1,0.75);
            //runForward(1,0.75);
            //setFoundation(true);
            //sleep(500);
            //sleep(3000);
            i++;
            telemetry.addData("imu calib status", imu.getCalibrationStatus().toString());
            telemetry.addData("i",i);
            telemetry.addData("angel",getAngle());
            telemetry.update();
        }
    }
}
