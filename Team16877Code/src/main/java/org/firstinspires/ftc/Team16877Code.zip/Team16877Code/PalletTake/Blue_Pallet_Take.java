package org.firstinspires.ftc.Team16877Code.PalletTake;

import android.webkit.WebHistoryItem;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;

import org.firstinspires.ftc.Team16877Code.AutonautsAPI;

@Autonomous(name = "Blue pallet take")
public class Blue_Pallet_Take extends AutonautsAPI {

    @Override
    public void runOpMode()
    {
        INIT();

        while (opModeIsActive())
        {
            runRight(1,0.75);
            runForward(1,0.75);

        }
    }

}
